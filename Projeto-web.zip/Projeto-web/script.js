
const produtos = [
    {
        id: 1,
        nome: "Frango Grelhado",
        categoria: "Refeições",
        preco: 450,
        descricao: "Frango grelhado acompanhado de batatas.",
        imagem: "imagens/frango-grelhado.jpg"
    },
    {
        id: 2,
        nome: "Hambúrguer Especial",
        categoria: "Hambúrgueres",
        preco: 350,
        descricao: "Hambúrguer com queijo, alface e molho da casa.",
        imagem: "imagens/hamburguer.jpg"
    },
    {
        id: 3,
        nome: "Pizza de Queijo",
        categoria: "Refeições",
        preco: 650,
        descricao: "Pizza com queijo derretido e molho de tomate.",
        imagem: "imagens/pizza.jpg"
    },
    {
        id: 4,
        nome: "Batatas Fritas",
        categoria: "Refeições",
        preco: 180,
        descricao: "Batatas crocantes preparadas na hora.",
        imagem: "imagens/batatas-fritas.jpg"
    },
    {
        id: 5,
        nome: "Sumo Natural",
        categoria: "Bebidas",
        preco: 120,
        descricao: "Sumo refrescante de fruta.",
        imagem: "imagens/sumo-natural.jpg"
    },
    {
        id: 6,
        nome: "Refrigerante",
        categoria: "Bebidas",
        preco: 80,
        descricao: "Bebida fresca para acompanhar a refeição.",
        imagem: "imagens/refrigerante.jpg"
    }
];

let carrinho = carregarDados("carrinho", []);
let pedidos = carregarDados("pedidos", []);

function carregarDados(chave, valorInicial) {
    try {
        const dados = localStorage.getItem(chave);
        return dados ? JSON.parse(dados) : valorInicial;
    } catch {
        return valorInicial;
    }
}

function guardarDados() {
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
}

function formatarPreco(valor) {
    return valor.toLocaleString("pt-MZ") + " MT";
}

function mostrarProdutos(categoria = "Todos") {
    const lista = document.getElementById("listaProdutos");

    const filtrados = categoria === "Todos"
        ? produtos
        : produtos.filter(p => p.categoria === categoria);

    lista.innerHTML = filtrados.map(p => `
        <article class="produto">
    <a href="detalhes-prato.html?id=${p.id}"
       class="linkDetalhePrato"
       aria-label="Ver detalhes de ${p.nome}">
        <img src="${p.imagem}" alt="${p.nome}" loading="lazy">
    </a>

    <div class="produtoInfo">
        <h3>
            <a href="detalhes-prato.html?id=${p.id}"
               class="linkDetalhePrato">
                ${p.nome}
            </a>
        </h3>
                <p>${p.descricao}</p>

                <div class="produtoRodape">
                    <span class="preco">${formatarPreco(p.preco)}</span>
                    <button class="adicionar" data-id="${p.id}">
                        + Adicionar
                    </button>
                </div>
            </div>
        </article>
    `).join("");
}

document.getElementById("categorias").addEventListener("click", evento => {
    const botao = evento.target.closest("[data-categoria]");
    if (!botao) return;

    document.querySelectorAll(".categoria").forEach(b => {
        b.classList.remove("ativa");
    });

    botao.classList.add("ativa");
    mostrarProdutos(botao.dataset.categoria);
});

document.getElementById("listaProdutos").addEventListener("click", evento => {
    const botao = evento.target.closest("[data-id]");
    if (!botao) return;

    const id = Number(botao.dataset.id);
    const produto = produtos.find(p => p.id === id);
    if (!produto) return;

    const existente = carrinho.find(item => item.id === id);

    if (existente) {
        existente.quantidade++;
    } else {
        carrinho.push({ ...produto, quantidade: 1 });
    }

    atualizarCarrinho();
});

function atualizarCarrinho() {
    const quantidade = carrinho.reduce(
        (soma, item) => soma + item.quantidade, 0
    );

    document.getElementById("quantidadeCarrinho").textContent = quantidade;
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
}


document.getElementById("botaoCarrinho").addEventListener("click", () => {
    if (carrinho.length === 0) {
        alert("O carrinho está vazio. Adiciona primeiro um prato.");
        return;
    }

    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    window.location.href = "finalizar-pedido.html";
});


function mostrarPedidos() {
    const lista = document.getElementById("listaPedidos");

    if (pedidos.length === 0) {
        lista.innerHTML = '<p class="vazio">Ainda não existem pedidos.</p>';
        return;
    }

    lista.innerHTML = pedidos.map(p => `
        <article class="pedido">
            <h3>Pedido #${p.id}</h3>
            <p><strong>Cliente:</strong> ${p.cliente}</p>
            <p><strong>Data:</strong> ${p.data}</p>
            <p><strong>Itens:</strong> ${
                p.itens.map(item => `${item.nome} x${item.quantidade}`).join(", ")
            }</p>
            <p><strong>Total:</strong> ${formatarPreco(p.total)}</p>
            <p><strong>Estado:</strong> ${p.estado}</p>
        </article>
    `).join("");
}

mostrarProdutos();
mostrarPedidos();
atualizarCarrinho();
