
const produtos = [
    {
        id: 1,
        nome: "Frango Grelhado",
        categoria: "Refeições",
        preco: 450,
        descricao: "Frango grelhado acompanhado de batatas.",
        imagem: "imagens/frango-grelhado.jpg"
    },
    {
        id: 2,
        nome: "Hambúrguer Especial",
        categoria: "Hambúrgueres",
        preco: 350,
        descricao: "Hambúrguer com queijo, alface e molho da casa.",
        imagem: "imagens/hamburguer.jpg"
    },
    {
        id: 3,
        nome: "Pizza de Queijo",
        categoria: "Refeições",
        preco: 650,
        descricao: "Pizza com queijo derretido e molho de tomate.",
        imagem: "imagens/pizza.jpg"
    },
    {
        id: 4,
        nome: "Batatas Fritas",
        categoria: "Refeições",
        preco: 180,
        descricao: "Batatas crocantes preparadas na hora.",
        imagem: "imagens/batatas-fritas.jpg"
    },
    {
        id: 5,
        nome: "Sumo Natural",
        categoria: "Bebidas",
        preco: 120,
        descricao: "Sumo refrescante de fruta.",
        imagem: "imagens/sumo-natural.jpg"
    },
    {
        id: 6,
        nome: "Refrigerante",
        categoria: "Bebidas",
        preco: 80,
        descricao: "Bebida fresca para acompanhar a refeição.",
        imagem: "imagens/refrigerante.jpg"
    }
];

const areaDetalhes = document.getElementById("detalhesPrato");
const parametros = new URLSearchParams(window.location.search);
const idPrato = Number(parametros.get("id"));
const prato = produtos.find(p => p.id === idPrato);

function formatarPreco(valor) {
    return Number(valor).toLocaleString("pt-MZ") + " MT";
}

function escaparHTML(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[c]);
}

if (!prato) {
    areaDetalhes.innerHTML = `
        <div class="detalheNaoEncontrado">
            <h2>Prato não encontrado</h2>
            <p>Este prato não existe ou já não está disponível.</p>
            <a href="index.html#menu" class="botaoPrincipal">
                Voltar ao menu
            </a>
        </div>
    `;
} else {
    areaDetalhes.innerHTML = `
        <article class="cartaoDetalhes">
            <div class="imagemDetalhes">
                <img src="${escaparHTML(prato.imagem)}"
                     alt="${escaparHTML(prato.nome)}">
            </div>

            <div class="informacaoDetalhes">
                <span class="categoriaDetalhes">
                    ${escaparHTML(prato.categoria)}
                </span>

                <h1>${escaparHTML(prato.nome)}</h1>

                <p class="descricaoDetalhes">
                    ${escaparHTML(prato.descricao)}
                </p>

                <p class="precoDetalhes">
                    ${formatarPreco(prato.preco)}
                </p>

                <label for="quantidadePrato">Quantidade</label>

                <div class="seletorQuantidade">
                    <button type="button" id="diminuir">−</button>
                    <input id="quantidadePrato"
                           type="number" min="1" max="99" value="1">
                    <button type="button" id="aumentar">+</button>
                </div>

                <p class="subtotalDetalhes">
                    Subtotal: <strong id="subtotalPrato">
                        ${formatarPreco(prato.preco)}
                    </strong>
                </p>

                <button type="button" id="adicionarDetalhes"
                        class="botaoAdicionarDetalhes">
                    Adicionar ao carrinho
                </button>
            </div>
        </article>
    `;

    const quantidadeInput = document.getElementById("quantidadePrato");
    const subtotal = document.getElementById("subtotalPrato");

    function obterQuantidade() {
        let quantidade = Number.parseInt(quantidadeInput.value, 10);

        if (!Number.isFinite(quantidade)) quantidade = 1;

        quantidade = Math.max(1, Math.min(99, quantidade));
        quantidadeInput.value = quantidade;

        return quantidade;
    }

    function atualizarSubtotal() {
        subtotal.textContent = formatarPreco(
            prato.preco * obterQuantidade()
        );
    }

    document.getElementById("diminuir").addEventListener("click", () => {
        quantidadeInput.value = Math.max(1, obterQuantidade() - 1);
        atualizarSubtotal();
    });

    document.getElementById("aumentar").addEventListener("click", () => {
        quantidadeInput.value = Math.min(99, obterQuantidade() + 1);
        atualizarSubtotal();
    });

    quantidadeInput.addEventListener("input", atualizarSubtotal);
    quantidadeInput.addEventListener("change", atualizarSubtotal);

    document.getElementById("adicionarDetalhes")
        .addEventListener("click", () => {
            const quantidade = obterQuantidade();

            let carrinho;

            try {
                carrinho = JSON.parse(
                    localStorage.getItem("carrinho") || "[]"
                );

                if (!Array.isArray(carrinho)) carrinho = [];
            } catch {
                carrinho = [];
            }

            const existente = carrinho.find(item => item.id === prato.id);

            if (existente) {
                existente.quantidade = Math.min(
                    99,
                    (Number(existente.quantidade) || 0) + quantidade
                );
            } else {
                carrinho.push({
                    ...prato,
                    quantidade
                });
            }

            try {
                localStorage.setItem("carrinho", JSON.stringify(carrinho));
            } catch {
                alert("Não foi possível guardar o carrinho. Tenta novamente.");
                return;
            }

            window.location.href = "finalizar-pedido.html";
        });
}
