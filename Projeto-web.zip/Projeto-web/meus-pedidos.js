
const lista = document.getElementById("listaMeusPedidos");
const totalPedidos = document.getElementById("totalPedidos");

function carregarPedidos() {
    try {
        return JSON.parse(localStorage.getItem("pedidos")) || [];
    } catch {
        return [];
    }
}

function formatarPreco(valor) {
    return Number(valor).toLocaleString("pt-MZ") + " MT";
}

function escaparHTML(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caracter => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[caracter]);
}

function mostrarMeusPedidos() {
    const pedidos = carregarPedidos();

    totalPedidos.textContent =
        `${pedidos.length} ${pedidos.length === 1 ? "pedido" : "pedidos"}`;

    if (pedidos.length === 0) {
        lista.innerHTML = `
            <div class="estadoVazio">
                <div class="iconeVazio">🛍️</div>
                <h3>Ainda não fizeste nenhum pedido</h3>
                <p>Explora o nosso menu e escolhe os teus pratos favoritos.</p>
                <a href="index.html#menu" class="botaoPrincipal">
                    Explorar menu
                </a>
            </div>
        `;
        return;
    }

    lista.innerHTML = pedidos.map(pedido => {
        const itens = Array.isArray(pedido.itens) ? pedido.itens : [];

        const estado = ["Recebido", "Em preparação", "Pronto", "Entregue"]
            .includes(pedido.estado) ? pedido.estado : "Recebido";

        return `
            <article class="cartaoPedido">
                <div class="pedidoTopo">
                    <div>
                        <span class="numeroPedido">
                            PEDIDO #${escaparHTML(pedido.id)}
                        </span>
                        <h3>${escaparHTML(pedido.cliente)}</h3>
                        <p class="dataPedido">${escaparHTML(pedido.data)}</p>
                    </div>

                    <span class="estadoPedido estado-${estado.replaceAll(" ", "")}">
                        ${escaparHTML(estado)}
                    </span>
                </div>

                <div class="itensPedido">
                    ${itens.map(item => `
                        <div class="linhaItem">
                            <span>
                                ${escaparHTML(item.nome)} × ${Number(item.quantidade) || 0}
                            </span>
                            <strong>
                                ${formatarPreco(
                                    (Number(item.preco) || 0) *
                                    (Number(item.quantidade) || 0)
                                )}
                            </strong>
                        </div>
                    `).join("")}
                </div>

                <div class="totalPedido">
                    <span>Total do pedido</span>
                    <strong>${formatarPreco(pedido.total)}</strong>
                </div>
            </article>
        `;
    }).join("");
}

mostrarMeusPedidos();

window.addEventListener("storage", evento => {
    if (evento.key === "pedidos") {
        mostrarMeusPedidos();
    }
});
