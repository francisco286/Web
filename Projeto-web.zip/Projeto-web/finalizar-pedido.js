
const CHAVE_CARRINHO = "carrinho";
const CHAVE_PEDIDOS = "pedidos";

let carrinho = carregar(CHAVE_CARRINHO, []);

const listaItens = document.getElementById("itensCarrinho");
const totalFinal = document.getElementById("totalFinal");
const formulario = document.getElementById("formFinalizar");
const tipoPedido = document.getElementById("tipoPedido");
const campoEndereco = document.getElementById("campoEndereco");
const enderecoCliente = document.getElementById("enderecoCliente");

function carregar(chave, padrao) {
    try {
        const dados = localStorage.getItem(chave);
        return dados ? JSON.parse(dados) : padrao;
    } catch {
        return padrao;
    }
}

function guardarCarrinho() {
    localStorage.setItem(CHAVE_CARRINHO, JSON.stringify(carrinho));
}

function formatarPreco(valor) {
    return Number(valor).toLocaleString("pt-MZ") + " MT";
}

function escaparHTML(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[c]);
}

function calcularTotal() {
    return carrinho.reduce(
        (soma, item) => soma + item.preco * item.quantidade,
        0
    );
}

function mostrarCarrinho() {
    if (carrinho.length === 0) {
        listaItens.innerHTML = `
            <div class="estadoVazio">
                <h3>O carrinho está vazio</h3>
                <p>Escolhe alguns pratos antes de finalizar.</p>
                <a href="index.html#menu" class="botaoPrincipal">
                    Explorar menu
                </a>
            </div>
        `;

        totalFinal.textContent = formatarPreco(0);
        formulario.querySelector("button[type='submit']").disabled = true;
        return;
    }

    formulario.querySelector("button[type='submit']").disabled = false;

    
listaItens.innerHTML = carrinho.map(item => `
    <article class="itemFinalizar">

        <img
            class="imagemItemCarrinho"
            src="${escaparHTML(item.imagem)}"
            alt="${escaparHTML(item.nome)}"
            onerror="this.style.display='none'"
        >

        <div class="itemFinalizarInfo">
            <h3>${escaparHTML(item.nome)}</h3>
            <p>${formatarPreco(item.preco)} por unidade</p>

            <div class="controlosQuantidade">
                <button type="button"
                    data-acao="menos"
                    data-id="${item.id}"
                    aria-label="Diminuir quantidade">−</button>

                <span>${item.quantidade}</span>

                <button type="button"
                    data-acao="mais"
                    data-id="${item.id}"
                    aria-label="Aumentar quantidade">+</button>

                <button type="button"
                    class="removerItem"
                    data-acao="remover"
                    data-id="${item.id}">
                    Remover
                </button>
            </div>
        </div>

        <strong>
            ${formatarPreco(item.preco * item.quantidade)}
        </strong>

    </article>
`).join("");


    totalFinal.textContent = formatarPreco(calcularTotal());
}

listaItens.addEventListener("click", evento => {
    const botao = evento.target.closest("[data-acao]");
    if (!botao) return;

    const id = Number(botao.dataset.id);
    const item = carrinho.find(p => p.id === id);
    if (!item) return;

    switch (botao.dataset.acao) {
        case "mais":
            item.quantidade++;
            break;

        case "menos":
            item.quantidade--;
            if (item.quantidade <= 0) {
                carrinho = carrinho.filter(p => p.id !== id);
            }
            break;

        case "remover":
            carrinho = carrinho.filter(p => p.id !== id);
            break;
    }

    guardarCarrinho();
    mostrarCarrinho();
});

tipoPedido.addEventListener("change", () => {
    const entrega = tipoPedido.value === "Entrega";

    campoEndereco.hidden = !entrega;
    enderecoCliente.required = entrega;

    if (!entrega) enderecoCliente.value = "";
});

formulario.addEventListener("submit", evento => {
    evento.preventDefault();

    if (carrinho.length === 0) {
        alert("Adiciona pelo menos um prato ao carrinho.");
        return;
    }

    const nome = document.getElementById("nomeCliente").value.trim();
    const telefone = document.getElementById("telefoneCliente").value.trim();
    const endereco = enderecoCliente.value.trim();

    if (nome.length < 2 || !telefone) {
        alert("Preenche corretamente o teu nome e telefone.");
        return;
    }

    if (tipoPedido.value === "Entrega" && !endereco) {
        alert("Indica o endereço para a entrega.");
        return;
    }

    const pedidos = carregar(CHAVE_PEDIDOS, []);

    const pedido = {
        id: Date.now(),
        cliente: nome,
        telefone,
        tipo: tipoPedido.value,
        endereco: tipoPedido.value === "Entrega" ? endereco : "",
        observacoes: document.getElementById("observacoes").value.trim(),
        itens: carrinho.map(item => ({ ...item })),
        total: calcularTotal(),
        estado: "Recebido",
        data: new Date().toLocaleString("pt-MZ")
    };

    try {
        pedidos.unshift(pedido);
        localStorage.setItem(CHAVE_PEDIDOS, JSON.stringify(pedidos));
        localStorage.removeItem(CHAVE_CARRINHO);
    } catch {
        alert("Não foi possível guardar o pedido. Tenta novamente.");
        return;
    }

    carrinho = [];

    alert("Pedido confirmado com sucesso!");

    window.location.href = "meus-pedidos.html";
});

mostrarCarrinho();
